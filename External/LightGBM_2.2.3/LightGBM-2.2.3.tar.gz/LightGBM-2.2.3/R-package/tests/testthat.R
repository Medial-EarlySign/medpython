library(testthat)
library(lightgbm)

test_check("lightgbm")
