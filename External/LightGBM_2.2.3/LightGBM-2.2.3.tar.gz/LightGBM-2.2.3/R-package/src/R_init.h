// Register Dynamic Symbols
#ifndef R_INIT_LIGHTGBM_H
#define R_INIT_LIGHTGBM_H

void R_init_lightgbm(DllInfo* info);

#endif // R_INIT_LIGHTGBM_H
